package student.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import student.inform.Student;
import student.service.IStudentService;
import student.service.impl.StudentServiceImpl;


public class queryBySmajorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L; 
    public queryBySmajorServlet() {
       super();     
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String major = request.getParameter("smajor");
		
		IStudentService service = new StudentServiceImpl ();
		
		List<Student> students = service.queryStudentBySmajor( major);
		System.out.println(students);
		
		request.setAttribute("students", students);
		request.getRequestDispatcher("queryBySno.jsp").forward(request, response);
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
