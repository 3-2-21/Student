/*
Navicat MySQL Data Transfer

Source Server         : StudentDB
Source Server Version : 80022
Source Host           : localhost:3306
Source Database       : studentinf

Target Server Type    : MYSQL
Target Server Version : 80022
File Encoding         : 65001

Date: 2021-04-13 21:07:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for students
-- ----------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `sid` int NOT NULL,
  `sname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sgender` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sage` int NOT NULL,
  `smajor` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sphone` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of students
-- ----------------------------
INSERT INTO `students` VALUES ('1', '112233', '闵敏', '女', '21', '英语', '15123417896');
INSERT INTO `students` VALUES ('2', '101012', '乐乐', '女', '19', '会计', '15122345678');
INSERT INTO `students` VALUES ('3', '1001121', '多多', '男', '20', '软件工程', '18980807890');
INSERT INTO `students` VALUES ('4', '101013', '李莉', '女', '21', '英语', '19983989385');
INSERT INTO `students` VALUES ('5', '100122', '王宇', '男', '21', '计算机网络', '15082745918');
INSERT INTO `students` VALUES ('6', '100127', '明明', '男', '20', '计算机网络', '1217652345');
INSERT INTO `students` VALUES ('7', '1920010', '王玉', '女', '21', '软件工程', '12392001121');
INSERT INTO `students` VALUES ('8', '192001112', '丽丽', '女', '21', '英语', '15982786677');
INSERT INTO `students` VALUES ('9', '192001111', '陈于', '男', '20', '软件工程', '15087692321');
INSERT INTO `students` VALUES ('10', '192001113', '苟灿', '男', '22', '计算机网络', '18898708799');
INSERT INTO `students` VALUES ('11', '11111', '娃娃', '女', '18', '会计', '12345678');
INSERT INTO `students` VALUES ('12', '192001114', '范林', '男', '21', '计算机网络', '17687659090');
INSERT INTO `students` VALUES ('13', '192001115', '琳琳', '女', '21', '软件工程', '15543216765');
INSERT INTO `students` VALUES ('14', '123123', '七七', '男', '22', '英语', '13124563421');
INSERT INTO `students` VALUES ('15', '192001117', '王磊', '男', '22', '计算机网络', '17789076548');
INSERT INTO `students` VALUES ('16', '192001121', '晨晨', '男', '21', '软件工程', '15987876543');
INSERT INTO `students` VALUES ('17', '192001120', '陈月', '女', '23', '计算机网络', '14532341234');
INSERT INTO `students` VALUES ('18', '192001118', '苟云', '男', '21', '会计', '19087907654');
INSERT INTO `students` VALUES ('19', '192001122', '宋心', '女', '20', '计算机网络', '15543567654');
INSERT INTO `students` VALUES ('20', '192001140', '谈宋', '男', '22', '软件工程', '18381160987');
